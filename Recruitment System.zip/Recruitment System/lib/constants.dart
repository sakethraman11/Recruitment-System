import 'package:flutter/cupertino.dart';

Color kWhite = Color(0xFFF1F1F2);
Color kGrey = Color(0xFFBCBABE);
Color kLightBlue = Color(0xFFA1D6E2);
Color kdarkBlue = Color(0xFF1995AD);